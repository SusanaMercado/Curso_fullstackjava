package Actividad1;

public class MiPrimerProgramaActividad1 {

	public static void main(String[] args) {
		String nombre = "Susana Mercado";
		System.out.println("Mi nombre es: "+nombre);
		
		int edad = 28;
		String a�os = " a�os";
		System.out.println("Mi edad es: "+ edad + a�os);
		
		String ciudad = "Pitrufqu�n";
		System.out.println("Mi ciudad natal es: "+ ciudad);
	}

}
